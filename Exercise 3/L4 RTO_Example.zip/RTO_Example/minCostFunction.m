function costFunction=minCostFunction(x);

% Variable identification
P1=x(1);
P2=x(2);
x1=x(3);
x2=x(4);
x3=x(5);
x4=x(6);

%Cost function: total use of fuel oil
costFunction=x1+x3;