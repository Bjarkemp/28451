function [c,ceq]=nonlinearcon(x)

%Variable identification
P1=x(1);
P2=x(2);
x1=x(3);
x2=x(4);
x3=x(5);
x4=x(6);

% Inequality constraints (none)
c=[];

%Equality constraints. Given by the model
ceq(1)=4.5*x1+0.1*x1^2+4.0*x2+0.06*x2^2-P1;
ceq(2)=4.0*x3+0.05*x3^2+3.5*x4+0.02*x4^2-P2;
ceq(3)=P1+P2-50;
ceq(4)=x2+x4-5;
